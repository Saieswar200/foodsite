#Omnifood landing page [v1].

This is a simple one-page website featuring the fictitious Omnifood brand. This is built and taught from a Udemy course [RWD and Development with HTML5 and CSS3](https://www.udemy.com/design-and-develop-a-killer-website-with-html5-and-css3/). 

The site also uses subtle animations using jQuery. Another version will make use of different tools/ languages to enhance the landing page's performance and development time. 
